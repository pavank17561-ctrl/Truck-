package com.truck.trip

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import java.util.Locale

class TripService : Service() {
    private var lm: LocationManager? = null
    private var wake: PowerManager.WakeLock? = null
    private var last: Location? = null

    companion object {
        @Volatile var km = 0.0
        @Volatile var speed = 0.0
        @Volatile var moving = false
        @Volatile var fix = false
        @Volatile var lat = 0.0
        @Volatile var lon = 0.0
        @Volatile var acc = 0.0
        @Volatile var loaded = false

        fun load(c: Context) {
            if (!loaded) {
                km = c.getSharedPreferences("trip", Context.MODE_PRIVATE).getString("km", "0")?.toDoubleOrNull() ?: 0.0
                loaded = true
            }
        }

        fun stateJson(c: Context): String {
            load(c)
            return String.format(
                Locale.US,
                "{\"km\":%.3f,\"speed\":%.1f,\"moving\":%b,\"fix\":%b,\"lat\":%.6f,\"lon\":%.6f,\"acc\":%.1f}",
                km, speed, moving, fix, lat, lon, acc
            )
        }
    }

    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            acc = l.accuracy.toDouble()
            if (l.accuracy > 150f) {
                fix = false
                return
            }
            fix = true
            lat = l.latitude
            lon = l.longitude
            val p = last
            if (p == null) {
                last = l
                return
            }
            val d = p.distanceTo(l).toDouble()
            if (l.hasSpeed()) {
                speed = l.speed * 3.6
                moving = speed >= 4.0
                last = l
                if (moving && d < 500) km += d / 1000.0
            } else {
                if (d >= 20.0) {
                    val dt = Math.max((l.time - p.time) / 1000.0, 1.0)
                    speed = d / dt * 3.6
                    moving = speed >= 4.0
                    last = l
                    if (moving && d < 500) km += d / 1000.0
                } else {
                    speed = 0.0
                    moving = false
                }
            }
            getSharedPreferences("trip", Context.MODE_PRIVATE).edit().putString("km", km.toString()).apply()
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val reset = intent?.getBooleanExtra("reset", false) ?: false
        if (reset) {
            km = 0.0
            loaded = true
            getSharedPreferences("trip", Context.MODE_PRIVATE).edit().putString("km", "0").apply()
        } else {
            load(this)
        }
        last = null
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n: Notification
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("trip", "Trip", NotificationManager.IMPORTANCE_LOW))
            n = Notification.Builder(this, "trip")
                .setContentTitle("Truck Trip chalu hai")
                .setContentText("GPS se KM gin raha hai")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        } else {
            @Suppress("DEPRECATION")
            n = Notification.Builder(this)
                .setContentTitle("Truck Trip chalu hai")
                .setContentText("GPS se KM gin raha hai")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(1, n)
        }
        if (wake == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "trucktrip:gps")
            wake?.acquire(24 * 60 * 60 * 1000L)
        }
        try {
            lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm?.removeUpdates(listener)
            lm?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener)
        } catch (e: SecurityException) {
            fix = false
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { lm?.removeUpdates(listener) } catch (e: Exception) {}
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) {}
        wake = null
        speed = 0.0
        moving = false
        fix = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
